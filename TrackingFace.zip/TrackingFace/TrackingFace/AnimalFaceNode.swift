import SceneKit

class AnimalFaceNode: SCNNode {
    
    // The code below is sourced from https://youtu.be/2CQDV2SOyOo example
    
    var options: [String]
    var index = 0
    
    // Set the size of face
    init(with options: [String], width: CGFloat = 0.3, height: CGFloat = 0.3) {
        self.options = options
        
        super.init()
        
        // Set a plane displaying animal face
        let plane = SCNPlane(width: width, height: height)
        // Call the first images in resource
        plane.firstMaterial?.diffuse.contents =  UIImage(named: options.first!)
        plane.firstMaterial?.isDoubleSided = true
        
        geometry = plane
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("Wrong")
    }
}

extension AnimalFaceNode {
    
    func updatePosition(for vectors: [vector_float3]) {
        // Update the position of new animal face
        let newPos = vectors.reduce(vector_float3(), +) / Float(vectors.count)
        position = SCNVector3(newPos)
    }
    
    func next() {
        // Call the next animal face
        index = (index + 1) % options.count
        
        // Set a plane displaying animal face
        if let plane = geometry as? SCNPlane {
            // Call the next images in resource
            plane.firstMaterial?.diffuse.contents = UIImage(named: options[index])
            plane.firstMaterial?.isDoubleSided = true
        }
    }
}


