import UIKit
import ARKit

// The code below is sourced from https://youtu.be/2CQDV2SOyOo example

class ViewController: UIViewController, ARSCNViewDelegate {

    @IBOutlet var sceneView: ARSCNView!

    // Set the animal characters
    let animalOptions = ["lion", "panda"]
    let features = ["animal"]
    var featureIndices = [[6]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the view's delegate
        sceneView.delegate = self

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARFaceTrackingConfiguration()

        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    
    @IBAction func handleTap(_ sender: UITapGestureRecognizer) {
        // Call the location user taps
        let location = sender.location(in: sceneView)
        // Create the result of tapping
        let results = sceneView.hitTest(location, options: nil)
        if let result = results.first,
           // Display the node of face tracking
            let node = result.node as? AnimalFaceNode {
            // Change to the next animal face
            node.next()
        }
    }
    
    func updateFeatures(for node: SCNNode, using anchor: ARFaceAnchor) {
        // Set the updated feature
        for (feature, indices) in zip(features, featureIndices) {
            let child = node.childNode(withName: feature, recursively: false) as? AnimalFaceNode
            let vertices = indices.map { anchor.geometry.vertices[$0] }
            child?.updatePosition(for: vertices)
        }
    }
    
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        
        // Create the device
        let device: MTLDevice!
        // Set the device to be default
        device = MTLCreateSystemDefaultDevice()
        // Call the face anchor
        guard let faceAnchor = anchor as? ARFaceAnchor else {
            return nil
        }
        // Set the geometry of tracking face
        let faceGeometry = ARSCNFaceGeometry(device: device)
        // Create a node displaying the face
        let node = SCNNode(geometry: faceGeometry)
        node.geometry?.firstMaterial?.fillMode = .lines
        node.geometry?.firstMaterial?.transparency = 0.0
        
        // Choose animal face from options
        let animalNode = AnimalFaceNode(with: animalOptions)
        animalNode.name = "animal"
        // Add the animal node into the node
        node.addChildNode(animalNode)
        // Change the next animal face
        updateFeatures(for: node, using: faceAnchor)
        
        return node
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let faceAnchor = anchor as? ARFaceAnchor,
        let faceGeometry = node.geometry as? ARSCNFaceGeometry else {
            return
        }
        // Update the geometry of tracking face
        faceGeometry.update(from: faceAnchor.geometry)
        // Change the next animal face
        updateFeatures(for: node, using: faceAnchor)
    }
}
